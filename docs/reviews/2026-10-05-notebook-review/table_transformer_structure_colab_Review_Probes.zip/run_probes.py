"""TTS review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, os, sys, types, zipfile, re, importlib
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/table_transformer_structure_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
S = importlib.import_module('table_transformer_structure_pipeline.samples'); M = importlib.import_module('table_transformer_structure_pipeline.metrics')
P = importlib.import_module('table_transformer_structure_pipeline.pipeline')
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']; md = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pipe_src = (repo / 'src/table_transformer_structure_pipeline/pipeline.py').read_text()
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'notebook_bytes': NB.stat().st_size,
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'asserts': [(i, l.strip()) for i in code if i not in (5, 7, 9, 11) for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'doubled_braces_in_markdown': [(i, m) for i in md for m in re.findall(r'\{\{[^}]*\}\}', src(i))],
    'adapt_layers_cloned_from_live_params': '"layers": {n: params[n].detach().clone() for n in names}' in pipe_src}

# P2 decode the embedded corpus (digest-checked), rebuild the paper split, recompute the grid prior
corpus = S.load_corpus()
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
disj = S.check_split_disjoint(splits)
papers = {k: {r['paper_id'] for r in v} for k, v in splits.items()}
prior = M.prior_baseline(splits['train'], splits['test'], labels=P.ADAPT_LABELS, threshold=P.RECOGNITION_THRESHOLD)
labels = {}
for r in corpus:
    for o in r['objects']: labels[o['label']] = labels.get(o['label'], 0) + 1
R['P2_corpus_split_prior'] = {'tables': len(corpus), 'papers': len({r['paper_id'] for r in corpus}), 'objects_per_label': labels,
    'split_tables': {k: len(v) for k, v in splits.items()}, 'split_papers': {k: len(v) for k, v in papers.items()},
    'papers_shared': {'train&test': len(papers['train'] & papers['test']), 'train&validation': len(papers['train'] & papers['validation']), 'validation&test': len(papers['validation'] & papers['test'])},
    'test_objects': sum(len(r['objects']) for r in splits['test']), 'train_spanning_cells': sum(1 for r in splits['train'] for o in r['objects'] if o['label'] == 'table spanning cell'),
    'grid_prior_test': {k: round(prior[k], 4) for k in ('map50', 'map75', 'map', 'mean_best_iou', 'grid_exact_at_threshold')},
    'grid_prior_recorded_kaggle': {'map50': 0.3868, 'map75': 0.2514, 'map': 0.2621, 'mean_best_iou': 0.5173, 'grid_exact_at_threshold': 0.0476},
    'licences': sorted({r.get('paper_license') for r in corpus})}

# P3 prose numbers vs the recorded Kaggle comparison
R['P3_prose_vs_record'] = {
    'prose_build_record': {'frozen_policy': {'map50': 0.852, 'map75': 0.761, 'map': 0.715}, 'selected': {'map50': 0.868, 'map75': 0.775, 'map': 0.722}, 'spanning_ap50_zero_to_selected': [0.748, 0.626], 'grid_agreement_zero_to_selected': [0.857, 0.762]},
    'recorded_kaggle_T4': {'frozen_policy': {'map50': 0.863, 'map75': 0.7616, 'map': 0.7197}, 'selected': {'map50': 0.8728, 'map75': 0.7675, 'map': 0.7255}, 'spanning_ap50_zero_to_selected': [0.748, 0.6191], 'grid_agreement_zero_to_selected': [0.8571, 0.7619], 'zero_shot': {'map50': 0.8873, 'map75': 0.7339, 'map': 0.6352}},
    'directions_agree': True}

# P4 BYOD through cell 15's sequence
def png(seed, size=(300, 200)):
    a = (np.random.default_rng(seed).random((size[1], size[0], 3)) * 255).astype(np.uint8); b = io.BytesIO(); Image.fromarray(a).save(b, 'PNG'); return b.getvalue()
def rows_for(i, g, label_override=None):
    rows = [f't{i},t{i}.png,table,10,10,290,190,{g}']
    rows += [f't{i},t{i}.png,{label_override or "table column"},{10 + 90 * c},10,{100 + 90 * c},190,{g}' for c in range(3)]
    rows += [f't{i},t{i}.png,table row,10,{10 + 60 * r},290,{70 + 60 * r},{g}' for r in range(3)]
    return rows
def ds(n, groups, extra_rows=(), extra_files=None, label_override=None):
    files = {f't{i}.png': png(i) for i in range(n)}
    lines = ['id,file,label,x_min,y_min,x_max,y_max,group'] + [r for i in range(n) for r in rows_for(i, f'g{i % groups}', label_override if i == 0 else None)] + list(extra_rows)
    files['structure.csv'] = '\n'.join(lines).encode(); files.update(extra_files or {}); return files
def mkzip(name, files):
    p = out / name
    with zipfile.ZipFile(p, 'w') as z:
        for k, v in files.items(): z.writestr(k, v)
    return p
def nb_byod(p):
    recs = S.load_byod_dataset(p); sp = S.split_dataset(recs, seed=42)
    m = {k: S.validate_dataset(v) for k, v in sp.items()}; S.check_split_disjoint(sp)
    return {k: x['n_records'] for k, x in m.items()}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:220]}
smallest = next((n for n in range(8, 120) if run('n', lambda n=n: nb_byod(mkzip('scan.zip', ds(n, n))))['verdict'] == 'accepted'), None)
cases = [
    run('40 tables, 10 groups', lambda: nb_byod(mkzip('g.zip', ds(40, 10)))),
    run('label "table column header"', lambda: nb_byod(mkzip('hdr.zip', ds(40, 10, label_override='table column header')))),
    run('label with different case "Table Row"', lambda: nb_byod(mkzip('case.zip', ds(40, 10, label_override='Table Column')))),
    run('row naming a missing image', lambda: nb_byod(mkzip('miss.zip', ds(40, 10, extra_rows=['tx,nothere.png,table,1,1,50,50,g1'])))),
    run('row without group', lambda: nb_byod(mkzip('nog.zip', ds(40, 10, extra_rows=['t0,t0.png,table row,10,10,290,40,'])))),
    run('two tables (two "table" boxes) on one image', lambda: nb_byod(mkzip('two.zip', ds(40, 10, extra_rows=['t0,t0.png,table,5,5,295,195,g0'])))),
]
R['P4_byod'] = {'stated_minimum': 'a training set needs 8..2,000 records', 'smallest_accepted_one_group_per_table': smallest, 'matrix': cases}
c15 = src(15).replace('USE_BYOD = False', 'USE_BYOD = True'); head = c15.split('    records = load_byod_dataset')[0]
def exec_upload(up, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: up)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(out)
    try:
        ns = {'Path': Path, 'os': os}; exec(compile(head, 'cell15', 'exec'), ns); return ns.get('file_name')
    finally: os.chdir(cwd)
R['P5_upload'] = {'cancelled': run('cancelled', lambda: exec_upload({})), 'outside Colab': run('outside', lambda: exec_upload(None, colab=False)), 'has_path_field': bool(re.search(r'BYOD_(PATH|ZIP)\s*=', src(15)))}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
for p in out.glob('*.zip'): p.unlink()
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:9000])
