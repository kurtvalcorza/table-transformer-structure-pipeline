"""Probes for the TBL review of tutorials/DIMER_Table_Intelligence_Workshop.ipynb.

CPU-only direct execution. The notebook's own code cells are executed in order with the three models replaced by
stand-ins; the SciTSR-PD parquet shards and the TAPAS tokenizer files are the real pinned files (downloaded once to
./cache). Nothing here is pretrained-model evidence: detection, structure and TAPAS outputs are synthetic.

Usage: python run_probes.py <notebook.ipynb> <results.json>
"""
from __future__ import annotations

import ast
import contextlib
import io
import json
import os
import sys
import tempfile
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent / "cache"
SCITSR = {
    "data/train-00000-of-00001.parquet": CACHE / "scitsr" / "data" / "train-00000-of-00001.parquet",
    "data/test-00000-of-00001.parquet": CACHE / "scitsr" / "data" / "test-00000-of-00001.parquet",
}


def cells_by_id(nb):
    return {c["id"]: "".join(c["source"]) for c in nb["cells"]}


def defs_only(src):
    """Imports, function definitions and plain assignments of a cell; no top-level calls."""
    tree = ast.parse(src)
    keep = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.Assign))]
    return ast.unparse(ast.Module(body=keep, type_ignores=[]))


class FakeBatch(dict):
    def to(self, _device):
        return self


class FakeProcessor:
    """Stand-in image processor: remembers the image and returns registered boxes for it."""

    def __init__(self, registry, id2label):
        self.registry = registry
        self.label2id = {v: k for k, v in id2label.items()}
        self.last = None

    def __call__(self, images, return_tensors="pt"):
        self.last = images
        return FakeBatch(pixel_values=None)

    def post_process_object_detection(self, out, target_sizes, threshold):
        import torch

        objs = [o for o in self.registry.get(id(self.last), []) if o["score"] >= threshold]
        return [{
            "scores": torch.tensor([o["score"] for o in objs], dtype=torch.float32),
            "labels": torch.tensor([self.label2id[o["label"]] for o in objs], dtype=torch.long),
            "boxes": torch.tensor([o["box"] for o in objs], dtype=torch.float32).reshape(-1, 4),
        }]


class FakeConfig:
    def __init__(self, id2label):
        self.id2label = id2label


class FakeModel:
    def __init__(self, id2label):
        self.config = FakeConfig(id2label)

    def __call__(self, **_kw):
        return None

    def parameters(self):
        return iter(())


STRUCT_LABELS = {0: "table", 1: "table column", 2: "table row", 3: "table column header",
                 4: "table projected row header", 5: "table spanning cell"}
DET_LABELS = {0: "table", 1: "table rotated"}


def run(nb_path, out_path):
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    C = cells_by_id(nb)
    results = {"notebook": str(nb_path), "probes": {}}
    work = Path(tempfile.mkdtemp(prefix="tbl_probe_"))
    os.chdir(work)

    import numpy as np
    import pandas as pd
    import torch
    from PIL import Image, ImageDraw, ImageFont, ImageOps  # noqa: F401

    registry = {}
    ns = {"__name__": "__main__", "np": np, "pd": pd, "torch": torch, "Image": Image, "ImageDraw": ImageDraw,
          "ImageFont": ImageFont, "ImageOps": ImageOps, "DEVICE": "cpu", "RUNTIME": {"device": "cpu"}}

    def ex(cid, src=None):
        code = C[cid] if src is None else src
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            exec(compile(code, cid, "exec"), ns)
        return buf.getvalue()

    # §3 config, §5 provenance helpers (no downloads), §6 SciTSR with the real pinned shards.
    ex("dimer-table-workshop-04")
    ex("dimer-table-workshop-08", defs_only(C["dimer-table-workshop-08"]))
    import huggingface_hub

    def fake_hf_hub_download(repo_id, filename, revision=None, repo_type=None, local_dir=None, **_kw):
        return str(SCITSR[filename])

    huggingface_hub.hf_hub_download = fake_hf_hub_download
    ns["hf_hub_download"] = fake_hf_hub_download
    ex("dimer-table-workshop-10")
    for cid in ("12", "13", "15", "17", "19", "21"):
        ex(f"dimer-table-workshop-{cid}")
    canonical = ns["canonical_tables"]
    results["canonical_table_ids"] = [x["source_id"] for x in canonical]

    # Stand-in detector: hugs the pasted table (3 px inset) except on one page, which gets no detection.
    miss_id = canonical[5]["source_id"]
    det_reg = {}

    def detect_table(image, threshold=None):
        boxes = det_reg.get(id(image))
        return [] if boxes is None else [dict(b) for b in boxes]

    for item in canonical:
        x0, y0, x1, y1 = item["page_gt_box"]
        if item["source_id"] != miss_id:
            det_reg[id(item["page"])] = [{"label": "table", "score": 0.99, "box": [x0 + 3, y0 + 3, x1 - 3, y1 - 3]}]
    ns["detect_table"] = detect_table
    # Run the detection loop of §12 without loading a model.
    det_src = C["dimer-table-workshop-23"]
    loop_src = det_src[det_src.index("_ = detect_table"):]
    ns.update(det_load_seconds=0.0, det_params=0, det_model=None, det_processor=None)
    ex("dimer-table-workshop-23", loop_src)
    ex("dimer-table-workshop-25")
    ex("dimer-table-workshop-28")

    # Stand-in structure model: returns the crop's own reference rows/columns, except that on one detected crop it
    # adds a spurious column (the 2026-09-26 Colab run saw a detected crop gain a column).
    sproc = FakeProcessor(registry, STRUCT_LABELS)
    smodel = FakeModel(STRUCT_LABELS)
    extra_col_id = canonical[6]["source_id"]
    for item in canonical:
        registry[id(item["gold_crop"])] = [dict(o, score=0.99) for o in item["gold_crop_objects"]
                                           if o["label"] in ("table row", "table column")]
        if item["det_crop"] is not None:
            objs = [dict(o, score=0.99) for o in item["det_crop_objects"] if o["label"] in ("table row", "table column")]
            if item["source_id"] == extra_col_id:
                cols = sorted([o for o in objs if o["label"] == "table column"], key=lambda o: o["box"][0])
                c = cols[-1]["box"]
                mid = (c[0] + c[2]) / 2
                objs = [o for o in objs if o["box"] != c]
                objs += [{"label": "table column", "score": 0.99, "box": [c[0], c[1], mid, c[3]]},
                         {"label": "table column", "score": 0.98, "box": [mid, c[1], c[2], c[3]]}]
            registry[id(item["det_crop"])] = objs
    ns.update(struct_processor=sproc, struct_model=smodel, struct_load_seconds=0.0, struct_params=0)
    s30 = C["dimer-table-workshop-30"]
    ex("dimer-table-workshop-30", s30[s30.index("def recognize_structure"):])
    for cid in ("32", "34", "36"):
        ex(f"dimer-table-workshop-{cid}")

    # ---- P01: a detection miss is counted as an exact detected-crop grid.
    sr = [r for r in ns["structure_rows"] if r["path"] == "detected_crop"]
    miss_row = next(r for r in sr if r["table_id"] == miss_id)
    hits = sum(1 for x in canonical if x["selected_detection"] is not None)
    true_exact = sum(1 for r in sr if r["grid_shape_exact"] and r["table_id"] != miss_id
                     and next(x for x in canonical if x["source_id"] == r["table_id"])["selected_detection"] is not None)
    reported = sum(r["grid_shape_exact"] for r in sr)
    results["probes"]["P01_detection_miss_counted_as_exact_grid"] = {
        "miss_table": miss_id, "miss_row": miss_row, "detection_hits": hits,
        "reported_detected_crop_grid_exact": int(reported), "exact_among_detected": int(true_exact),
        "defect_present": bool(miss_row["grid_shape_exact"]),
    }

    # ---- P02: the activity cell cannot be rerun after §19 unloads the structure model.
    act_cid = next(c["id"] for c in nb["cells"] if "ACTIVITY_STRUCTURE_THRESHOLD = " in "".join(c["source"]))
    first = ex(act_cid)
    complex_cid = next(c["id"] for c in nb["cells"] if "complex_tables=" in "".join(c["source"]))
    # Restore stand-ins for the complex probe if a fixed notebook reloads the model itself.
    ns["AutoImageProcessor"] = type("AIP", (), {"from_pretrained": staticmethod(lambda *a, **k: sproc)})
    ns["TableTransformerForObjectDetection"] = type("TTO", (), {"from_pretrained": staticmethod(
        lambda *a, **k: type("W", (), {"to": lambda self, d: type("E", (), {"eval": lambda s: smodel})()})())})
    ex(complex_cid)
    ns["ACTIVITY_STRUCTURE_THRESHOLD"] = 0.98
    src = C[act_cid].replace("ACTIVITY_STRUCTURE_THRESHOLD = 0.95", "ACTIVITY_STRUCTURE_THRESHOLD = 0.98")
    try:
        second = ex(act_cid, src)
        rerun = {"ok": True, "tail": second[-300:]}
    except Exception as e:  # noqa: BLE001
        rerun = {"ok": False, "error": f"{type(e).__name__}: {e}"}
    results["probes"]["P02_activity_rerun_after_run_all"] = {
        "first_run_ok": True, "first_tail": first[-200:], "rerun_after_section19": rerun,
        "defect_present": not rerun["ok"],
    }

    # Questions (real gold tables).
    q_cid = next(c["id"] for c in nb["cells"] if "qa_records=[]" in "".join(c["source"]))
    ex(q_cid)

    # ---- P04: does TapasTokenizer drop rows (truncation=True) for any canonical question?
    from transformers import TapasTokenizer

    tok = TapasTokenizer.from_pretrained(str(CACHE / "tapas"))
    trunc = []
    for rec in ns["qa_records"]:
        item = next(x for x in canonical if x["source_id"] == rec["table_id"])
        df = pd.DataFrame(item["grid"][1:], columns=item["grid"][0], dtype=object)
        full = tok(table=df, queries=[rec["question"]], padding=False, truncation=False)
        n = len(full["input_ids"][0]) if isinstance(full["input_ids"][0], list) else len(full["input_ids"])
        trunc.append({"q": rec["id"], "tokens": n})
    over = [t for t in trunc if t["tokens"] > 512]
    results["probes"]["P04_tapas_truncation"] = {"max_tokens": max(t["tokens"] for t in trunc),
                                                 "over_512": over, "defect_present": bool(over)}

    # TAPAS stand-in: answers lookups correctly, sums with SUM.
    def tapas_answer(table, question):
        return {"coordinates": [], "cells": [table[1][1]], "aggregation": "NONE", "numeric_answer": None,
                "answer": table[1][1]}

    ns.update(tapas_answer=tapas_answer, tapas_params=0, tapas_load_seconds=0.0, AGGREGATIONS=("NONE", "SUM", "AVERAGE", "COUNT"))
    tapas_src = C["dimer-table-workshop-44"]
    ex("dimer-table-workshop-44", tapas_src[tapas_src.index("def compute_numeric"):tapas_src.index("def tapas_answer")])
    rest = [c["id"] for c in nb["cells"] if c["cell_type"] == "code"]
    start = rest.index("dimer-table-workshop-46")
    log = {}
    for cid in rest[start:]:
        src = C[cid]
        if "USE_BYOD" in src and "byod_result=None" in src:
            continue
        try:
            log[cid] = ex(cid)[-1500:]
        except Exception as e:  # noqa: BLE001
            log[cid] = f"ERROR {type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"
    results["default_path_cell_tails"] = log
    out_dir = Path(ns["OUTPUT_DIR"])
    results["exports"] = sorted(str(p.relative_to(out_dir)) for p in out_dir.rglob("*") if p.is_file())

    # ---- P06: waterfall units.
    wf = json.loads((out_dir / "waterfall.json").read_text(encoding="utf-8"))
    results["probes"]["P06_waterfall_units"] = {"waterfall": wf,
                                                "qa_reported_as_counts": any(
                                                    isinstance(v, int) and k != "questions"
                                                    for k, v in wf.get("qa", {}).items())}

    # ---- P03/P05: BYOD branch with stand-ins.
    byod_cid = next(c["id"] for c in nb["cells"] if "byod_result=None" in "".join(c["source"]))
    byod = work / "byod"
    (byod / "pages").mkdir(parents=True)
    item = canonical[0]
    item["page"].save(byod / "pages" / "page001.png")
    item["page"].save(byod / "pages" / "page002.png")  # no OCR rows for this page
    x0, y0 = item["page_gt_box"][:2]
    lines = ["page_id,text,x0,y0,x1,y1,order"]
    for k, c in enumerate(item["cells"]):
        b = c["box"]
        lines.append(f'page001,"{c["text"]}",{b[0]+x0},{b[1]+y0},{b[2]+x0},{b[3]+y0},{k}')
    (byod / "ocr.csv").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (byod / "questions.csv").write_text("id,page_id,question,accepted_answer\nq1,page001,What?,12\n", encoding="utf-8")
    page_reg = {}
    for name in ("page001.png", "page002.png"):
        pass
    orig_open = Image.open

    def detect_any(image, threshold=None):
        w, h = image.size
        return [{"label": "table", "score": 0.99, "box": [x0 + 3, y0 + 3, x0 + item["image"].width - 3,
                                                           y0 + item["image"].height - 3]}]

    ns["detect_table"] = detect_any

    def rec_struct(image, threshold=None):
        return [dict(o, score=0.99) for o in item["gold_crop_objects"] if o["label"] in ("table row", "table column")]

    ns["recognize_structure"] = rec_struct

    def tapas_num(table, question):
        return {"coordinates": [[0, 1]], "cells": ["12"], "aggregation": "SUM", "numeric_answer": 12.0,
                "answer": "SUM > 12"}

    ns["tapas_answer"] = tapas_num
    byod_runs = {}
    for label, path, mutate in (
        ("valid", byod, None),
        ("bad_coordinate", byod, "x0"),
        ("empty_path", Path(""), None),
    ):
        if mutate:
            bad = work / "byod_bad"
            if not bad.exists():
                import shutil
                shutil.copytree(byod, bad)
                txt = (bad / "ocr.csv").read_text(encoding="utf-8").splitlines()
                parts = txt[1].split(",")
                parts[2] = "twelve"
                txt[1] = ",".join(parts)
                (bad / "ocr.csv").write_text("\n".join(txt) + "\n", encoding="utf-8")
            path = bad
        src = C[byod_cid]
        ns["USE_BYOD"] = True
        ns["BYOD_PATH"] = str(path)
        before = set(p for p in out_dir.rglob("*"))
        try:
            text = ex(byod_cid, src.replace("byod_result=None\nif USE_BYOD:", "byod_result=None\nif True:", 1)
                      if "if USE_BYOD:" in src else src)
            byod_runs[label] = {"ok": True, "stdout": text[-1500:]}
        except Exception as e:  # noqa: BLE001
            byod_runs[label] = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        after = set(p for p in out_dir.rglob("*"))
        byod_runs[label]["new_files"] = sorted(str(p.relative_to(out_dir)) for p in after - before)
        if label == "valid":
            byod_runs[label]["byod_result"] = json.loads(json.dumps(ns.get("byod_result"), default=str))
    results["probes"]["P03_byod"] = byod_runs
    valid = byod_runs["valid"]
    res = valid.get("byod_result") or {}
    pages = {o["page_id"]: o for o in res.get("outputs", [])} if isinstance(res, dict) else {}
    results["probes"]["P03_byod"]["summary"] = {
        "valid_ok": valid["ok"],
        "page002_without_ocr_reported": "page002" in pages or "page002" in valid.get("stdout", ""),
        "files_written_by_byod": valid["new_files"],
        "bad_coordinate_error": byod_runs["bad_coordinate"].get("error"),
    }
    ans = []
    for o in res.get("outputs", []) if isinstance(res, dict) else []:
        ans += o.get("answers", [])
    results["probes"]["P05_accepted_answer_numeric_format"] = {
        "answers": ans,
        "defect_present": any(a.get("accepted_answer") == "12" and a.get("exact_string_match") is False for a in ans),
    }
    Path(out_path).write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print(json.dumps({k: v.get("defect_present", v.get("summary")) if isinstance(v, dict) else v
                      for k, v in results["probes"].items()}, indent=1, default=str))


if __name__ == "__main__":
    sys.path.insert(0, str(HERE))
    run(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
